//
// Created by wen on 2016-05-19.
//

#ifndef QTP_FRAMEWORK_QTP_FRAMEWORK_H
#define QTP_FRAMEWORK_QTP_FRAMEWORK_H

#include "qtp_version.h"

namespace qtp {

DECLARE_VERSION(QTP_FRAMEWORK, 0, 0, 11)

} //namespace qtp

#endif //QTP_FRAMEWORK_QTP_FRAMEWORK_H
