java -Dsbe.output.dir=. -Dsbe.target.namespace=test -Dsbe.target.language=cpp -jar sbe-tool-1.3.6-RC3-SNAPSHOT-all.jar test.xml
